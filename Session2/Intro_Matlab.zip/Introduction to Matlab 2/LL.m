function L = LL(theta,y,x,n)
b = theta(1:4);
sig2 = theta(5);
L = n*.5*log(2*pi)+n*.5*log(sig2)+(y-x*b)'*(y-x*b)./(2*sig2);
end
