%% Introduction to MATLAB %%

% Center of Econometrics Research, Sungkyunkwan University

% 3rd Session

% Ver. 20160228

%% Directory Setting

cd('C:\Users\�� ����\Dropbox\CER_MATLAB')
% change working directory

% addpath('C:\Users\�� ����\Dropbox\CER_MATLAB')
% add this directory

%% Matrix - Multidimensional matrix

clc;
clear all;

% Define matrix

A = [1:9];
A = reshape(A,3,3);
A = A';

B = [10:18];
B = reshape(B,3,3);
B = B';

C = [19:27];
C = reshape(C,3,3);
C = C';

D = A;
D(:,:,2) = B;
D(:,:,3) = C;

D

E = cat(3,A,B,C);
% cat(DIM,A1,A2,A3,A4,...)

% Dimension

ndims(E)
ndims(A)

% Extract elements

E(1,:,:)
E(:,2,:)
E(:,:,3)
E(1,2,3)

%% Plot - 3D

clc;
clear all;

x = [-2:0.1:2];
y = [-2:0.1:2];
z = 1/(2*pi) * exp(-1/2 * (x.^2 + y.^2));

plot3(x,y,z);

clc;
clear all;

[x,y] = meshgrid(-2:0.1:2);
z = 1/(2*pi) * exp(-1/2 * (x.^2 + y.^2));
mesh(x,y,z)
surf(x,y,z)


z2 = x.*exp(-x.^2 - y.^2);
mesh(x,y,z2)
meshc(x,y,z2)
meshz(x,y,z2)
surf(x,y,z2)
surfc(x,y,z2)

%% Optimization (Linear Regression)

clc
clear all
close all

DATA = xlsread('toy3.xlsx');

[n k] = size(DATA);

y = DATA(:,1);
x = [ones(n,1), DATA(:,2:4)];


y0 = DATA(:,1);
x0 = [ones(n,1), DATA(:,2:4)];
[n0 k0] = size(DATA);

%% 1) OLS

options = optimset('fminunc');
options = optimset(options,'Display','iter-detailed','TolFun',1e-10,'TolX',1e-10,'MaxFunEvals',1e+10,'MaxIter',100);

% Refer to
% http://kr.mathworks.com/help/optim/ug/fminunc.html
% for various options you can set

b0 = ones(4,1);
s = @(b) (y-x*b)'*(y-x*b);
[betaols, fval, exitflag] = fminunc(s,b0,options);

% betaols = fminunc(s,b0,options);

% alternatvie : fminsearch(fun, x0, options);

% Usage
% x  =  fminunc(fun,x0,options)

% Exitflag
% 
% 1
% Magnitude of gradient smaller than the TolFun tolerance.
%  
% 2
% Change in x was smaller than the TolX tolerance.
%  
% 3
% Change in the objective function value was less than the TolFun tolerance.
%  
% 5
% Predicted decrease in the objective function was less than the TolFun tolerance.
%
% 0
% Number of iterations exceeded MaxIter or number of function evaluations exceeded MaxFunEvals.
% 
% -1
% Algorithm was terminated by the output function.
% 
% -3
% Objective function at current iteration went below ObjectiveLimit. 

% or
beta = (x'*x)\x'*y;

yhat = x*beta;
e = y-x*beta;

rss = e'*e;
tss = y'*y;
ess = tss-rss;

sig2 = rss/(n-k);
R2 = ess/tss;
VCV = inv(x'*x)*sig2;

% t-test 
% H0 : beta_1 = 1 ,beta_2 = 0, ... ,beta_4 = 0
tstat = beta./sqrt(diag(VCV));
Pval = 2*(1-tcdf(abs(ttest),n-k));

% F-test 
% H0 : beta_2 =  ...  = beta_4 = 0
R = [zeros(3,1), eye(3,3)];
q = rank(R);

fstat = (R*beta)'*inv(sig2*R*inv(x'*x)*R')*(R*beta)/q;
Pval2 = 1-fcdf(ftest,q,n-k);

%% 2) MLE
% y~N(x*beta, sig2*eye(n))

% Method 1

theta0 = ones(5,1);

[thetamle, lval, exitflag, output, grad, hess] = fminunc(@(theta) LL(theta,y0,x0,n0),theta0, options);
betamle = thetamle(1:4);
sig2mle = thetamle(5);

grad = grad(1:4);
hess = hess(1:4,1:4);

Rcov = inv(hess);
Rse = sqrt(diag(hess));
mletstat = betamle./Rse;

% Method 2

options = optimset('fmincon');
options = optimset(options,'Display','iter','TolFun',1e-10,'TolX',1e-10,'MaxFunEvals',1e+10,'MaxIter',1e+10);

% Refer to
% http://kr.mathworks.com/help/optim/ug/fmincon.html
% for various options you can set

A = [ 0 0 0 0 -1];
b = 0;

[thetamle2, lval2, exitflag2, output2, grad2, hess2] = fmincon(@(theta) LL(theta,y0,x0,n0),theta0,A,b,[],[],[],[],[],options);
betamle2 = thetamle2(1:4);
sig2mle2 = thetamle2(5);

grad2 = grad2(1:4);
hess2 = hess2(1:4,1:4);

Rcov2 = inv(hess2);
Rse2 = sqrt(diag(hess2));
mletstat2 = betamle2./Rse2;

% Usage
% x = fmincon(fun,x0,A,b,Aeq,beq,lb,ub,nonlcon,options)
% 
% Ax<b
%
% x0 
%  Initial point for x   
% 
% Aineq 
%  Matrix for linear inequality constraints   
% 
% bineq 
%  Vector for linear inequality constraints   
% 
% Aeq 
%  Matrix for linear equality constraints   
% 
% beq 
%  Vector for linear equality constraints  
% 
% lb Vector of lower bounds   
% ub Vector of upper bounds   
% 
% nonlcon 
%  Nonlinear constraint function   

% Exitflag
% 
% All Algorithms:
%  
% 1
% First-order optimality measure was less than options.TolFun, and maximum constraint violation was less than options.TolCon.
%  
% 0
% Number of iterations exceeded options.MaxIter or number of function evaluations exceeded options.MaxFunEvals.
%  
% -1
% Stopped by an output function or plot function.
%  
% -2
% No feasible point was found.
%  
% trust-region-reflective, interior-point, and sqp algorithms:
%  
% 2
% Change in x was less than options.TolX and maximum constraint violation was less than options.TolCon.
%  
% trust-region-reflective algorithm only:
%  
% 3
% Change in the objective function value was less than options.TolFun and maximum constraint violation was less than options.TolCon.
%  
% active-set algorithm only:
% 
% 4
% Magnitude of the search direction was less than 2*options.TolX and maximum constraint violation was less than options.TolCon.
%  
% 5
% Magnitude of directional derivative in search direction was less than 2*options.TolFun and maximum constraint violation was less than options.TolCon.
% 
% interior-point and sqp algorithms:
% 
% -3
% Objective function at current iteration went below options.ObjectiveLimit and maximum constraint violation was less than options.TolCon.

%% Using external packages - MFE Toolbox
% Refer to 
% http://www.kevinsheppard.com/MFE_Toolbox

cd('C:\Users\�� ����\Dropbox\CER_MATLAB\MFE Toolbox\kevinsheppard-mfe_toolbox-a93d075a449e')
run('addToPath.m')
% press 'n' to all answers

cd('C:\Users\�� ����\Dropbox\CER_MATLAB')
% change directory

winopen('MFE Toolbox Documentation.pdf')

[B,TSTAT,S2,VCV,VCVWHITE,R2,RBAR,YHAT] = ols(y,x,0);

%% Result Save

savehead = '20160302'; %set proper name% 

saveformat = '.mat';

save([savehead,saveformat]); 