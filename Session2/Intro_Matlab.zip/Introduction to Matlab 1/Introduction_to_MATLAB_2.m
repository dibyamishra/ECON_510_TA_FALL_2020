%% Introduction to MATLAB

% Center of Econometrics Research, Sungkyunkwan University
% by Seung Hee Lee - PhD student in Indiana Univ.
% edited by Luke Min - PhD student in Rice Univ.

% 1st Session

% Ver. 20190201

%% Directory Setting

cd('C:\Users\Luke Min\Desktop\1. Rice University\Matlab\Introduction to Matlab')
% change working directory

addpath('C:\Users\Luke Min\Desktop\1. Rice University\Course Work\2019 Spring\ECON 511 (Econometrics 2)\Problem Sets\Answers\PS1\Computational Exercises')
% add this directory

%% Random sampling

clc; % clear command window
clear all; % clear variables and functions from memory

a = rand(5,1)
% random sampling from U[0,1]

b = randn(5)
% random sampling from N(0,1)

c = randperm(10)
% to create arrays of random integer values that have no repeated values

d = 5 + 3*randn(1000,1)
% random sampling from N(5,9)

mean(d)
var(d)

%% Matrix - Advance

clc;
clear all;

DATA = xlsread('toy2.xlsx');

% Submatrix

date = DATA(:,1);
y = DATA(:,2);
demeaned = DATA(:,3);
microsoft = DATA(:,4);

y2015 = DATA(2265:end,2);
y2014 = DATA(2013:2264,2);
return2014 = DATA(2013:2264,1:3);

% Stacking matrix

returns = [y, demeaned];
z = [y, demeaned; date, microsoft];
zz = [y, demeaned; [1, 2]];

% Empty matrix

a = [];

D = DATA;
D(:,4) = [];

% Reshape

b = [1:9]

b2 = reshape(b,3,3)

c = [1:5; 6:10]

c2 = reshape(c,5,2)

c3 = reshape(c',5,2)

c4 = reshape(c3,2,5)

d = b2

d2 = rot90(d)

d

d3 = fliplr(d)
d4 = flipud(d)

d

d5 = circshift(d,1)
d6 = circshift(d,[0,1])
d7 = circshift(d,[1,1])

d

d8 = repmat(d,2,1)
d9 = repmat(d,2,3)

% Sum and mean

b2

sum(b2)
sum(b2,2)

mean(b2)
mean(b2,2)

%% Plot - Basic

clc;
clear all;

DATA = xlsread('toy2.xlsx');

date = DATA(:,1);
y = DATA(:,2);
demeaned = DATA(:,3);
microsoft = DATA(:,4);

[n k] = size(DATA);
x = [1:n];
x = x';
% generate positive integer 1 to n

figure(1)
plot(x,y)
plot(y)
plot(y,'.')
% basic 2D plot

% option
%                color               shape                    linespec
%          b     blue          .     point              -     solid
%          g     green         o     circle             :     dotted
%          r     red           x     x-mark             -.    dashdot 
%          c     cyan          +     plus               --    dashed   
%          m     magenta       *     star             (none)  no line
%          y     yellow        s     square
%          k     black         d     diamond
%          w     white         v     triangle (down)
%                              ^     triangle (up)
%                              <     triangle (left)
%                              >     triangle (right)
%                              p     pentagram
%                              h     hexagram

figure(2)
plot(x,y,'rd--')
% 2D plot with option

figure(3)
plot(x,y)
xlabel('No.')
ylabel('rate')
title('S&P 500 return')
axis([100 2500 3 5])
%axis([xmin xmax ymin ymax])
legend('S&P 500')

%% Plot - Various plots

close all;

% plotyy
plotyy(x,y,x,demeaned)
legend('return','demeaned return')

plot(y)
hold on
plot(demeaned)
legend('return','demeaned return')

% Scatter

scatter(y,demeaned,'rd')

% Bar

for i = 1:2
y(n+i) = 0;
end
y_w = reshape(y,5,(n+2)/5);
interval = [1:5];
bar(interval,y_w) % interval = n times k, y_w = k times N 

% Histogram

y = DATA(:,2);

hist(y,10) %hist(variable, # of intervals)

% Subplot

figure(1)
subplot(2,2,1)
plot(x,y)
xlabel('No.')
ylabel('rate')
title('S&P 500 return')
axis tight
legend('S&P 500')

subplot(2,2,2)
plotyy(x,y,x,demeaned)
legend('S&P 500','demeaned')
title('S&P 500 return and demeaned return')

subplot(2,2,3)
hist(y)
title('Histogram of S&P 500 return')

subplot(2,2,4)
plotyy(x,y,x,microsoft)
legend('S&P 500','Microsoft')
title('S&P 500 return and Microsoft')

% Save

print -djpeg 20160226.jpeg % for pdf, print -dpdf exercise.pdf

%% Control Flow - IF

clc;
clear all;
close all;

x = randn(100,1);

m = mean(x);

% Basic Structure

% if condition
% statement
% end

% Logic Symbol

% == equal
% ~= not equal
% < less than
% > greater than
% <= less than or equal to
% >= greater than or equal to

% Example

if mean(x)>=0
    ans1 = msgbox({'mean(x)=<0'})
end

% Extenstion

% IF~ELSE

% if condition
% statement1
% else
% statement2
% end

% Example

if mean(x)<=0
    ans1 = msgbox({'mean(x)=<0'});
else
    ans2 = msgbox({'mean(x)=>0'});
end

% IF~ELSEIF~ELSE

% if condition1
% statement1
% elseif condition2
% statement2
% else
% statement3
% end

% Example

if mean(x)==0
    ans1 = msgbox({'mean(x)=0'});
elseif mean(x)<0
    ans2 = msgbox({'mean(x)<0'});
else
    ans3 = msgbox({'mean(x)>0'});
end

%% Control Flow - SWITCH

% Basic Structure

% switch variable
% case value1
% statement1
% case value2
% statement2
% otherwise
% statement3
% end

method = 'Bilinear';

switch lower(method)
    case {'linear','bilinear'}
     disp('Method is linear')
    case 'cubic'
     disp('Method is cubic')
    case 'nearest'
     disp('Method is nearest')
    otherwise
     disp('Unknown method.')
end



% Example
m=3;
switch m
    case m < 0
        m = abs(m);
    case m == 0
        m = m+1;
    otherwise
        m = m^2;
end
m

%% Control Flow - FOR

% Basic Structure

% for variable = expression
% statements
% end

% Example

clc
clear all

x = randn(100,1);
[n k] = size(x);
agg = 0;

for i = 1:n
    agg = agg+x(i);
end

% Extension

% For & If

clear agg
agg = 0;

for i = 1:n
    if x(i) > 0
        agg = agg + x(i)
    end
end

% For & For

clc
clear all

y = randn(100,10);
[n k] = size(y);
agg = 0;

for i = 1:n
    for j = 1:k
        agg = agg + y(i,j);
    end
end

total = sum(y(:));

% Break

seq = [1:100];
sigma = 0;

for i = 1:100
    sigma = sigma + seq(i);
    if sigma > 1000
        break
    end
end


%% Result Save

savehead = '20160226'; %set proper name% 

saveformat = '.mat';

save([savehead,saveformat]); 